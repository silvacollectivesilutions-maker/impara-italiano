# Parlora 5.51 · código 94

Creado por German Silva Chavez.

## Acceso
Mi cuaderno → Laboratorio de Sofía. También en Sofía → ⋮ → Laboratorio de Sofía.

## Funciones implementadas
- Buscar notas, hojas, diccionarios, sesiones y texto ya preparado de materiales compartidos, siempre del perfil actual. Hasta20 coincidencias. Abrir la fuente; pedir a Gemma una respuesta basada en hasta5 fragmentos, con citas y fragmentos guardados. Si no hay coincidencias no se inicia inferencia.
- Diccionarios personales: crear, añadir, editar palabra/significado/ejemplo/categoría/artículo/plural. A–Z, deduplicación y favoritos conservados. Continúa disponible ampliar con Gemma.
- Mis errores: capturar respuestas incorrectas de hojas y evaluaciones; añadir o confirmar correcciones propuestas por Sofía. Detección de repeticiones entre eventos guardados, orden por frecuencia, marcar revisado y practicar el punto. No interpreta automáticamente todo el historial del chat.
- Apartados de estudio con nombre propio: hojas reales con explicación, ejemplos y ejercicios generados por Gemma. Guardadas en Mis temas y Mis apartados; se pueden renombrar, exportar o eliminar desde Mis temas. Son secciones internas, no código ni nuevas pestañas ejecutables creadas por el modelo.
- Evaluaciones breves generadas sobre un tema o material elegido. Tres opciones por pregunta, validación del contrato, comprobación según la solución propuesta por IA, avance y respuestas persistentes. Se puede salir y continuar. No cambia la evaluación fija del curso ni genera acreditación oficial.
- Entrevista adaptativa: puesto y objetivo elegidos por el usuario, una pregunta italiana con traducción española por turno, comentarios sobre la respuesta y continuación con contexto reciente.
- Herramientas adicionales: asistente general, redacción/revisión, resúmenes de material, planificación, ayuda con código, comparación de opciones, práctica laboral e historia interactiva. Las propuestas son texto: no ejecutan código, no crean recordatorios ni envían mensajes externos.

## Persistencia y límites
Se mantiene el repositorio de documentos de cada perfil, escritura atómica, recuperación y respaldo/restauración existentes. Nuevo tipo lab version1; revisiones para rechazar páginas antiguas y no resucitar sesiones eliminadas. Las sesiones guardan los últimos12 turnos completos; al modelo se envían fragmentos de los últimos4 y el objetivo, hastaaproximadamente7000 caracteres. Entradas hasta4000 caracteres; máximo400 documentos/perfil y200KB/documento, como antes.

Cámara corregida en5.50, datos, modelos, voces, avatar, cursos, imágenes, videos, progreso, navegación y firma originales conservados. No hay descarga de modelos ni voces nueva. Las herramientas de generación requieren tener Gemma local activado. Se guardan respuestas completas que cumplen el contrato; ante respuestas inválidas se ofrece reintentar. Las preguntas, explicaciones y soluciones de IA requieren revisión humana.

Fotos y PDF no se indexan automáticamente: abrir primero en Conectar y compartir para preparar su texto. Materiales de bandeja compartida mantienen su política anterior y no se incluyen en el respaldo académico; las consultas conservan el fragmento utilizado aunque el original ya no esté disponible. Los enlaces son texto, no navegación web.

## Validación
Compilación Java/D8, resolución de referencias contra todos los DEX, saltos/try/payload, firma original, manifiesto y comparación de métodos fuera de las familias editadas. Pruebas JVM de esquemas, persistencia, revisiones, cola de guardado, aislamiento, A–Z/favoritos, deduplicación de errores, calificación reanudable, búsqueda/citas, apartados y respaldo/restauración clonada. También se repiten las pruebas de almacenamiento previas. Ver los reportes incluidos.

No se ha ejecutado la interfaz Android, la inferencia real de Gemma ni el audio en teléfono/emulador en este entorno. Hace falta comprobar la experiencia completa en el dispositivo.
