from pathlib import Path
import subprocess,zipfile
root=Path(__file__).resolve().parent;work=root.parent
families={p.stem for p in (root/'src/com/germansilva/italianomaestro').glob('*.java')}
def run(args,report):
 with (root/report).open('w') as out:subprocess.run(args,cwd=work,stdout=out,stderr=subprocess.STDOUT,check=True)
sources=[str(p.relative_to(work)) for directory in ['src','supportsrc','stubs'] for p in (root/directory).rglob('*.java')]
(root/'java-sources.txt').write_text('\n'.join(sources))
run(['java','-jar','build551/deps/ecj.jar','-17','-nowarn','-cp','build551/deps/android-api2.jar:build551/deps/json.jar:build551/deps-extra/sherpa-api.jar','-d','build551/appclasses','@build551/java-sources.txt'],'compile.txt')
with zipfile.ZipFile(root/'release.jar','w') as z:
 for p in (root/'appclasses').rglob('*.class'):
  if p.stem.split('$')[0] in families:z.write(p,str(p.relative_to(root/'appclasses')))
(root/'dex').mkdir(exist_ok=True)
run(['java','-cp','build551/deps/r8.jar','com.android.tools.r8.D8','--min-api','31','--lib','build551/deps/android-api2.jar','--output','build551/dex','build551/release.jar'],'d8.txt')
run(['java','-Xmx2g','-cp','build551/classes:build551/deps/*','Patch550'],'patch-report.txt')
run(['java','-Xmx2g','-cp','build551/classes:build551/deps/*','Verify550'],'verification.txt')
run(['java','-cp','build551/classes:build551/deps/*','CheckHooks'],'hook-tests.txt')
run(['python','build551/assemble.py'],'assembly.txt')
run(['java','-cp','build551/classes:build551/deps/*','Sign'],'signature.txt')
print('PASS release compiled, DEX/native hooks verified, assembled and signed')
