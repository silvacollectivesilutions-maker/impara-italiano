from pathlib import Path
import zipfile,struct

def manifest(data):
 b=bytearray(data);pos=8;strings=[];locations=[];changed=[]
 while pos<len(b):
  kind,header,size=struct.unpack_from('<HHI',b,pos)
  if kind==1:
   count,styles,flags,start,style_start=struct.unpack_from('<IIIII',b,pos+8)
   def length(p,wide=False):
    if wide:
     n=struct.unpack_from('<H',b,p)[0];p+=2
     if n&0x8000:n=((n&0x7fff)<<16)|struct.unpack_from('<H',b,p)[0];p+=2
    else:
     n=b[p];p+=1
     if n&128:n=((n&127)<<8)|b[p];p+=1
    return n,p
   for i in range(count):
    at=pos+start+struct.unpack_from('<I',b,pos+header+i*4)[0]
    n,at=length(at,not flags&256)
    if flags&256:n,at=length(at);enc='utf-8';raw=n
    else:enc='utf-16-le';raw=n*2
    strings.append(bytes(b[at:at+raw]).decode(enc));locations.append((at,raw,enc))
  if kind==0x102:
   offset,stride,count=struct.unpack_from('<HHH',b,pos+24)
   for i in range(count):
    at=pos+16+offset+i*stride;name=strings[struct.unpack_from('<I',b,at+4)[0]]
    if name=='versionCode':
     assert struct.unpack_from('<I',b,at+16)[0]==51
     struct.pack_into('<I',b,at+16,52);changed.append(name)
    if name=='versionName':
     si=struct.unpack_from('<I',b,at+16)[0];p,n,enc=locations[si];assert strings[si]=='5.8';value='5.9'.encode(enc);assert len(value)==n;b[p:p+n]=value;changed.append(name)
  pos+=size
 assert sorted(changed)==['versionCode','versionName'],changed
 return b

source=Path('Italiano_Maestro_5_8_Adjunto_Unico.apk')
with zipfile.ZipFile(source) as old,zipfile.ZipFile('work60/unsigned59.apk','w',zipfile.ZIP_DEFLATED,compresslevel=1) as out:
 for item in old.infolist():
  n=item.filename
  if n.startswith('META-INF/'):continue
  data=old.read(n)
  if n=='AndroidManifest.xml':data=manifest(data)
  replacement=Path('work60/patched-'+n)
  if n.endswith('.dex') and replacement.exists():data=replacement.read_bytes()
  out.writestr(item,data)
 out.writestr('classes9.dex',Path('work60/classes9.dex').read_bytes())
print('APK 5.9 assembled.')
