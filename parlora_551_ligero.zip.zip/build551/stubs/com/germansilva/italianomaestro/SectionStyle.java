package com.germansilva.italianomaestro;
class SectionStyle{enum Area{VERBS}static void fix(android.view.View v,Area a){}}