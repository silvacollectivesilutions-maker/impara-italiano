package com.germansilva.italianomaestro;
import java.util.*;
final class SpeechText {
 static String clean(String text){return EasyText.clean(text).replaceAll("(?m)^\\s*[#*•]+\\s*", "").replace("|",", ").replace("→",", ").replaceAll("[*_`#]","").replaceAll("\\s+"," ").trim();}
 static String[] chunks(String text){String value=clean(text);if(value.length()<=40)return value.isEmpty()?new String[0]:new String[]{value};ArrayList<String> out=new ArrayList<>();for(String sentence:value.split("(?<=[.!?;:])\\s+")){while(sentence.length()>300){int at=sentence.lastIndexOf(' ',300);if(at<1)at=300;out.add(sentence.substring(0,at).trim());sentence=sentence.substring(at).trim();}if(!sentence.isEmpty())out.add(sentence);}return out.toArray(new String[0]);}
}
