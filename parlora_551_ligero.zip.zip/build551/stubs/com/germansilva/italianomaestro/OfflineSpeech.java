package com.germansilva.italianomaestro;class OfflineSpeech{}
