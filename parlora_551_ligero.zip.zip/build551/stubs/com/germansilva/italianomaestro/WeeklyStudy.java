package com.germansilva.italianomaestro;
class WeeklyStudy{WeeklyStudy(MainActivity a){}void lesson(int d){}void home(){}}