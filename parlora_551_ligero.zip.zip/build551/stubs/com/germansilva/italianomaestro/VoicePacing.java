package com.germansilva.italianomaestro;
/** Calm Paola synthesis; preserve the original sample rate and pitch. */
final class VoicePacing {
 static final int PAUSE_MS=340;
 static float speed(float requested){if(Float.isNaN(requested)||Float.isInfinite(requested))requested=1f;return Math.max(.55f,Math.min(.9f,requested*.82f));}
}
