package com.germansilva.italianomaestro;
class CleanNotebook{static void apply(MainActivity a,int p){}}