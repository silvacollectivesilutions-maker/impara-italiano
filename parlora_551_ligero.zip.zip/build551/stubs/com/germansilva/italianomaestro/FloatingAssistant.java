package com.germansilva.italianomaestro;
class FloatingAssistant{static void attach(MainActivity a,android.widget.FrameLayout s){}}