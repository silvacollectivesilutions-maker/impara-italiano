package com.germansilva.italianomaestro;import java.util.*;
class ChatRequest{final String system,current;final List<Turn> turns;ChatRequest(String s,List<Turn> t,String c){system=s;turns=t;current=c;}static class Turn{final boolean user;final String text;Turn(boolean u,String t){user=u;text=t;}}}
