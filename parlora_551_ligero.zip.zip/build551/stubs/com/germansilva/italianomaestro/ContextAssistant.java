package com.germansilva.italianomaestro;
class ContextAssistant{static void install(MainActivity a){}static void open(MainActivity a){}}