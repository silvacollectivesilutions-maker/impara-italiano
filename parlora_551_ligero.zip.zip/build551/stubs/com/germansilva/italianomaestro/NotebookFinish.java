package com.germansilva.italianomaestro;
class NotebookFinish{static void bind(MainActivity a,android.view.View v){}}