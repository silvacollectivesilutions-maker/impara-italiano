package com.germansilva.italianomaestro;class AcademyScreen{MainActivity a;int tab;}
