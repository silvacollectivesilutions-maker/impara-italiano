package com.germansilva.italianomaestro;class CourseScreen{MainActivity a;}
