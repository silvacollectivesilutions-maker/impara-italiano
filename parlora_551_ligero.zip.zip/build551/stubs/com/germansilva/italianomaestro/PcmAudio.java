package com.germansilva.italianomaestro;
final class PcmAudio {
 // Mono PCM16: every frame occupies two bytes. Round up to a complete frame.
 static int bufferBytes(int minimum,int rate){if(minimum<=0||rate<=0)throw new IllegalArgumentException("Invalid audio configuration");long bytes=Math.max((long)minimum,((long)rate/4)*2);bytes=(bytes+1)&~1L;if(bytes>Integer.MAX_VALUE)throw new IllegalArgumentException("Audio buffer too large");return (int)bytes;}
 static short[] convert(float[] samples){short[] pcm=new short[samples.length];for(int i=0;i<samples.length;i++){float s=samples[i];if(Float.isNaN(s))s=0;pcm[i]=(short)Math.round(Math.max(-1f,Math.min(1f,s))*(s<0?32768f:32767f));}return pcm;}
}
