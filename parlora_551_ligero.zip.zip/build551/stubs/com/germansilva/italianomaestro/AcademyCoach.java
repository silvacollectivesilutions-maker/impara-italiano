package com.germansilva.italianomaestro;class AcademyCoach{MainActivity a;}
