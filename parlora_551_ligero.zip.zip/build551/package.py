from pathlib import Path
import zipfile,hashlib,json,struct
b=Path('build551');root=Path.cwd();apk=root/'Parlora_5_51.apk'
with zipfile.ZipFile('Parlora_5_50.apk') as old,zipfile.ZipFile(apk) as z:
 assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))
 assert set(z.namelist())-set(old.namelist())=={'classes45.dex'}
 assert not set(old.namelist())-set(z.namelist())
 changed=[]
 for n in old.namelist():
  if old.read(n)!=z.read(n):
   assert n.endswith('.dex') or n=='AndroidManifest.xml',n
   changed.append(n)
 for n in z.namelist():
  if n.endswith('.dex'):assert z.read(n)==(b/'merged'/n).read_bytes(),n
 with apk.open('rb') as f:
  for item in z.infolist():
   if item.compress_type==0:
    f.seek(item.header_offset+26);nl,el=struct.unpack('<HH',f.read(4));assert (item.header_offset+30+nl+el)%4==0,item.filename
for n in ['build-final.txt','signature.txt','verification.txt','hook-tests.txt','scope-check.txt','lab-tests.txt','storage-regression.txt','manifest-tests.txt']:
 assert (b/n).read_text().startswith('PASS'),n
(b/'package-report.txt').write_text('PASS APK CRC, unique entries, DEX match, alignment, version5.51/code94. All assets/models/OCR/native libraries/avatar/scenes/icons/resources byte-identical to5.50; only manifest and scoped DEX changed, classes45.dex added.\nSHA256 '+hashlib.sha256(apk.read_bytes()).hexdigest()+'\nChanged '+str(changed)+'\n')
out=root/'Parlora_5_51_Fuentes.zip'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
 z.write('Parlora_5_50_Fuentes.zip','previous/Parlora_5_50_Fuentes.zip')
 z.write(b/'ESTADO_ACTUAL.md','ESTADO_ACTUAL.md')
 for folder in ['src','supportsrc','stubs','testsrc','cameratestfixtures','replacements','deps-extra']:
  for p in (b/folder).rglob('*'):
   if p.is_file():z.write(p,str(p))
 for p in b.iterdir():
  if p.suffix in ['.java','.py','.txt','.json']:z.write(p,str(p))
 for n in changed+['classes45.dex']:
  p=b/'merged'/n
  if p.is_file():z.write(p,str(p))
with zipfile.ZipFile(out) as z:
 assert z.testzip() is None
 assert not any(n.endswith(('.keystore','.jks','.tar.bz2')) for n in z.namelist())
items=[]
for p,id,v in [(apk,'libfile_0e53c15804c881919cc824de5f30dd26',54),(out,'libfile_988d569593dc8191a047e353932a6f34',49)]:items.append(dict(local_path=str(p),purpose='replace_library_file',library_file_id=id,expected_current_version=v,library_file_name=p.name,version_reason='Parlora5.51: laboratorio con búsqueda local y fuentes, diccionarios personales, errores, apartados, evaluaciones, entrevistas y herramientas de asistencia offline'))
(b/'uploads.json').write_text(json.dumps({'uploads':items}))
print((b/'package-report.txt').read_text())
