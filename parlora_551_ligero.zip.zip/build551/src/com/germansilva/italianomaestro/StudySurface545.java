package com.germansilva.italianomaestro;
import android.view.View;import android.graphics.drawable.GradientDrawable;
/** Presentation roles: card, Italian, Spanish, usage. All body text keeps full width. */
final class StudySurface545{
 static final int ROLE=0x7e005501;
 static int role(View v){Object r=v.getTag(ROLE);return r instanceof Integer?(Integer)r:0;}
 static int color(int panel,int accent,boolean night,int role){if(role<1||role>4)return panel;float f=role==1?(night?.10f:.045f):role==2?(night?.22f:.13f):role==3?(night?.10f:.045f):(night?.045f:.02f);return ColorMath542.mix(panel,accent,f);}
 static int fill(MainActivity a,View v,int fallback){int r=role(v);return r==0?fallback:color(ThemeCatalog.get(a).panel,ThemeCatalog.get(a).accent,SimpleAppearance.dark(a),r);}
 static int ink(MainActivity a,View v,int inherited){return role(v)==0?inherited:ColorMath542.ink(fill(a,v,0));}
 static GradientDrawable shape(MainActivity a,View v,int c){GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{ColorMath542.top(c),ColorMath542.bottom(c)});g.setCornerRadius(a.dp(role(v)==1?14:10));g.setStroke(a.dp(1),ColorMath542.mix(c,ThemeCatalog.get(a).accent,role(v)==1?.50f:.30f));return g;}
}
