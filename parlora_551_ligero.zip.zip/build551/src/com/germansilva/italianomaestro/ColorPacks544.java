package com.germansilva.italianomaestro;
import java.util.*;
/** Offline curated RGB colors, no resolution-dependent bitmap packs or remote downloads. */
final class ColorPacks544{
 static final String[] PACKS={"Clásicos","Joyas","Océano","Aurora","Metales","Tierra","Botánica","Pasteles","Noche","Italia"};
 static final String[][] LABELS={
 {"Zafiro","Esmeralda","Azul real","Amatista","Frambuesa","Cobre","Titanio","Oliva","Champán","Menta","Hielo","Lavanda"},
 {"Rubí","Granate","Jade","Turmalina","Ópalo","Topacio","Lapislázuli","Tanzanita","Cuarzo rosa","Malaquita","Aguamarina","Ámbar"},
 {"Atlántico","Pacífico","Mar Adriático","Mar profundo","Azul laguna","Turquesa","Coral marino","Espuma","Bruma azul","Arena marina","Nácar","Abisal"},
 {"Boreal","Orquídea","Ultravioleta","Cian eléctrico","Magenta suave","Azul cometa","Rosa aurora","Índigo polar","Luz celeste","Violeta seda","Nebulosa","Verde aurora"},
 {"Oro antiguo","Bronce","Latón","Cobre rosado","Acero","Plata","Platino","Oro rosa","Níquel","Peltre","Grafito metálico","Champán rosado"},
 {"Terracota","Canela","Chocolate","Café","Arcilla","Desierto","Caramelo","Almendra","Duna","Ocre","Cacao","Avellana"},
 {"Bosque","Pino","Musgo","Salvia","Eucalipto","Helecho","Pistacho","Té verde","Albahaca","Hoja nueva","Laurel","Bambú"},
 {"Rosa pétalo","Melocotón","Lila nube","Azul algodón","Crema vainilla","Verde suave","Malva perla","Coral seda","Limón crema","Azul glaciar","Rosa té","Violeta hielo"},
 {"Obsidiana","Carbón","Medianoche","Azul tinta","Ciruela","Burdeos","Petróleo","Pizarra","Café nocturno","Verde nocturno","Índigo oscuro","Humo"},
 {"Verde Italia","Rosso","Azzurro","Mármol","Limone","Vino toscano","Olivo toscano","Terracota Roma","Costa Amalfi","Venezia","Caffè italiano","Sabbia"}};
 static final String[] HEX={
 "123852 125E54 214F9C 58408B 7D315B 854729 314653 40602C F0E2BD D5F0E7 DCE9FF ECDFF8",
 "8C2344 64233A 16725C 2B6267 BDE5DB B97E25 25427B 4B3A85 F4D1DE 176B45 A2DAD7 D0A04E",
 "153F62 164F75 26667C 0D293D 227D8A 188B91 C77868 DAF2ED C9DFED EBD9B8 EAE5DF 09202E",
 "345D69 755394 493875 116C82 9B487D 35539A EAC6E0 3E4278 C3E7F3 9B85BC 53476D 28745E",
 "8A652B 795B3A 9B833E A06A5D 526677 C6CDD3 DFE2E5 E6C4B9 7A8587 8D9495 353E48 E9D5C1",
 "A1533F 8D543A 593E32 684A3D B7755E D8B98B B5804B E8D6BD C6AC87 A77B31 453129 A17B57",
 "204F3D 1B463C 54633D AAB99E 719E91 48784D CDDCAD B4C7A0 34734C C0DEA3 5A7044 81955A",
 "F3D4DD F6D7C5 E5D8F2 D5E6F7 F7EACB DCEED8 E9DBE6 F5D1CA F1EDC8 D4EDF1 EBD7D2 DCDFF6",
 "14191F 24282C 101C36 1A2949 3E2947 4A2338 133B42 374958 352925 16342E 26294E 4A515B",
 "16734A A52F40 2467A2 F2EEE6 EEDAA0 6A314B 657449 B76B4D 337C97 437B80 574131 E7D7B3"};
 static final int[] COLORS=new int[120];static final String[] NAMES=new String[120];
 static{for(int p=0;p<PACKS.length;p++){String[] h=HEX[p].split(" ");if(h.length!=12||LABELS[p].length!=12)throw new IllegalStateException("Incomplete pack");for(int i=0;i<12;i++){COLORS[p*12+i]=(int)(0xff000000L|Long.parseLong(h[i],16));NAMES[p*12+i]=LABELS[p][i];}}}
 static String hex(int c){return String.format(Locale.ROOT,"#%06X",c&0xffffff);}
 static Integer parse(String value){String s=value==null?"":value.trim();if(s.startsWith("#"))s=s.substring(1);if(!s.matches("[a-fA-F0-9]{6}"))return null;return (int)(0xff000000L|Long.parseLong(s,16));}
 static String normal(String s){return java.text.Normalizer.normalize(s,java.text.Normalizer.Form.NFD).replaceAll("\\p{M}+","").toLowerCase(Locale.ROOT).trim();}
 static boolean visible(int i,int pack,String query){if(i<0||i>=COLORS.length)return false;String q=normal(query);return q.isEmpty()?(pack<0||i/12==pack):normal(NAMES[i]+" "+PACKS[i/12]+" "+hex(COLORS[i])).contains(q);}
 static final int[][] PAIRS={{0,1},{12,16},{24,31},{36,42},{52,51},{60,67},{72,78},{84,89},{98,104},{108,111}};
}
