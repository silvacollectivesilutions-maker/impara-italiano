package com.germansilva.italianomaestro;
final class MotionMath542{
 static float x(int i,double seconds){return (i%2==0?.07f:.91f)+(float)Math.sin(seconds*.23+i*1.4)*.035f;}
 static float y(int i,double seconds){return .18f+(i%3)*.27f+(float)Math.sin(seconds*.34+i*1.7)*.065f;}
 static boolean run(boolean attached,boolean visible,boolean focus,boolean allowed,boolean page){return attached&&visible&&focus&&allowed&&page;}
}
