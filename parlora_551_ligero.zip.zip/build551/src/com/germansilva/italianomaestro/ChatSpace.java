package com.germansilva.italianomaestro;
/** Shared compact vertical dimensions in dp. Does not alter lesson font size. */
final class ChatSpace {
 static final int HEADER=52,AVATAR=145,HINTS=46,CONTROL=36,COMPOSER=42,NAV=40;
 static boolean hideAvatar(boolean keyboard,boolean reading){return keyboard||reading;}
 static int reserved(boolean reading){return HEADER+(reading?0:AVATAR+4)+14+HINTS+COMPOSER+NAV;}
}
