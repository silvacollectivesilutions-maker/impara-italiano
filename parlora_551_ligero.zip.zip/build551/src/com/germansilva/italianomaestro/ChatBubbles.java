package com.germansilva.italianomaestro;
import android.view.*;import android.widget.*;import java.util.*;
/** Builds the final bubble explicitly, retaining the original text watchers and action callbacks. */
public final class ChatBubbles{
 private static final int INK=0xffffffff;
 static void detach(View v){if(v!=null&&v.getParent() instanceof ViewGroup)((ViewGroup)v.getParent()).removeView(v);}
 static ArrayList<View> children(ViewGroup g){ArrayList<View> r=new ArrayList<>();for(int i=0;i<g.getChildCount();i++)r.add(g.getChildAt(i));return r;}
 static void buttons(View v,View table,List<Button> out){if(v==table)return;if(v instanceof Button)out.add((Button)v);else if(v instanceof ViewGroup)for(View child:children((ViewGroup)v))buttons(child,table,out);}
 public static TextView create(MainActivity a,String value,boolean user){if(user)MoreCards546.user(a,value);
  TextView text=a.legacyMessage(value,user);if(a.page!=1||a.chat==null)return text;
  View old=text;while(old.getParent() instanceof View&&old.getParent()!=a.chat)old=(View)old.getParent();
  if(old.getParent()!=a.chat||!(old instanceof ViewGroup))return text;
  int index=a.chat.indexOfChild(old);View table=old.findViewWithTag("study-columns");ArrayList<Button> all=new ArrayList<>();buttons(old,table,all);
  Button audio=null,translate=null,explain=null,columns=null,spanishAudio=null;
  for(Button b:all){String d=String.valueOf(b.getContentDescription()),label=b.getText().toString();if(d.contains("columnas"))columns=b;else if(d.contains("traducción"))translate=b;else if(d.contains("español")&&d.contains("Escuchar"))spanishAudio=b;else if(b.getTag()==text||d.contains("Paola")||d.contains("Escuchar o detener"))audio=b;else if(label.contains("Explicar")||label.contains("significado")||label.contains("Rayos X"))explain=b;}
  ArrayList<TextView> translations=new ArrayList<>();for(View v:children((ViewGroup)old))if(v instanceof TextView&&!(v instanceof Button)&&v!=text)translations.add((TextView)v);
  LinearLayout bubble=new LinearLayout(a);bubble.setOrientation(LinearLayout.VERTICAL);bubble.setPadding(a.dp(11),a.dp(9),a.dp(11),a.dp(4));bubble.setBackground(new WallStyle.Bubble(a,user));bubble.setTag(0x7e002602,user);bubble.setOnLongClickListener(v->{ChatLook542.palette(a,user);return true;});
  LinearLayout body=new LinearLayout(a);body.setOrientation(LinearLayout.VERTICAL);detach(text);text.setTag(0x7e002601,true);text.setTextColor(a.prefs.getInt("chat_text_color",INK));text.setTextSize(a.prefs.getInt("chat_text_size",16));text.setIncludeFontPadding(false);text.setPadding(0,0,0,0);text.setLineSpacing(a.dp(3),1);body.addView(text,new LinearLayout.LayoutParams(-1,-2));bubble.addView(body,new LinearLayout.LayoutParams(-1,-2));
  for(TextView t:translations){detach(t);t.setTag(0x7e002601,true);t.setTextColor(a.prefs.getInt("chat_text_color",INK));t.setPadding(a.dp(7),a.dp(7),a.dp(7),a.dp(7));SofiaGlass.surface(a,t,10,false,0,false);bubble.addView(t,new LinearLayout.LayoutParams(-1,-2));}
  if(spanishAudio!=null){detach(spanishAudio);CompactSofia.fit(a,spanishAudio,null,0);bubble.addView(spanishAudio,new LinearLayout.LayoutParams(-2,a.dp(36)));}
  if(table!=null){detach(table);bubble.addView(table,new LinearLayout.LayoutParams(-1,-2));}
  LinearLayout actions=new LinearLayout(a);actions.setGravity(Gravity.END|Gravity.CENTER_VERTICAL);
  if(audio!=null)ActionStrip543.add(a,actions,audio,"Oír",46);if(translate!=null)ActionStrip543.add(a,actions,translate,"Traducir",64);if(explain!=null)ActionStrip543.add(a,actions,explain,"Explicar",62);if(columns!=null)ActionStrip543.add(a,actions,columns,"Columnas",68);
  Button shareButton=DeskUI.button(a,"Compartir",()->ShareHub549.reply(a,text),false);ActionStrip543.add(a,actions,shareButton,"Compartir",36);Button saveButton=DeskUI.button(a,"Guardar",()->Repaso546.save(a,text.getText().toString(),""),false);ActionStrip543.add(a,actions,saveButton,"Guardar",36);Button colorButton=DeskUI.button(a,"◉",()->ChatLook542.palette(a,user),false);colorButton.setContentDescription(user?"Cambiar color de mis mensajes":"Cambiar color de mensajes de Sofía");ActionStrip543.add(a,actions,colorButton,"◉",32);
  HorizontalScrollView strip=new HorizontalScrollView(a);strip.setHorizontalScrollBarEnabled(false);strip.setFillViewport(false);strip.setClipToPadding(false);strip.addView(actions,new ViewGroup.LayoutParams(-2,-2));bubble.addView(strip,new LinearLayout.LayoutParams(-1,-2));
  a.chat.removeView(old);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(user?a.dp(20):0,a.dp(4),user?0:a.dp(12),a.dp(4));a.chat.addView(bubble,index,lp);
  a.root.post(()->ButtonStudio.apply(a));StudyDesk.selection(a,text);return text;
 }
 static void add(MainActivity a,LinearLayout row,Button b,int width,String label,int icon){detach(b);CompactSofia.fit(a,b,label,width);if(icon!=0)SofiaGlass.action(a,b,icon);row.addView(b,new LinearLayout.LayoutParams(a.dp(width),a.dp(36)));}
}
