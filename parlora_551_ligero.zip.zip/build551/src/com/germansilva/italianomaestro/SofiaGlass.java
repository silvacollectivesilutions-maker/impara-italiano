package com.germansilva.italianomaestro;
import android.content.res.ColorStateList;
import android.graphics.*;
import android.graphics.drawable.*;
import android.view.View;
import android.widget.Button;

/** Native translucent surfaces and vector actions; 36 dp visuals in 48 dp touch targets. */
final class SofiaGlass extends Drawable {
 static final int INK=0xfff3f1e8,PURPLE=0xff28685f;
 Shader premium;int premiumColor,premiumHeight;View target;final MainActivity owner; final Paint p=new Paint(3);final float d,radius;final int icon;final boolean active,circle;
 SofiaGlass(MainActivity a,float r,boolean on,int symbol,boolean round){owner=a;d=a.getResources().getDisplayMetrics().density;radius=r*d;active=on;icon=symbol;circle=round;}
 int base(){return active||icon==4||(target!=null&&target.isSelected())?ThemeCatalog.get(owner).primary:AppearancePalette.control(SimpleAppearance.dark(owner));}
 RectF frame(){RectF f=new RectF(getBounds());if(circle){float r=Math.max(12*d,Math.min(f.width(),f.height())/2-6*d);f.set(f.centerX()-r,f.centerY()-r,f.centerX()+r,f.centerY()+r);}else f.inset(d,d);return f;}
 public void draw(Canvas c){RectF f=frame();float r=circle?f.width()/2:radius;
  p.setShader(null);p.setStyle(Paint.Style.FILL);int color=target==null?base():ChatLook542.color(owner,target,base());if(premium==null||premiumColor!=color||premiumHeight!=getBounds().height()){premiumColor=color;premiumHeight=getBounds().height();premium=new LinearGradient(0,f.top,0,Math.max(f.top+1,f.bottom),ColorMath542.top(color),ColorMath542.bottom(color),Shader.TileMode.CLAMP);}p.setColor(color);p.setShader(premium);c.drawRoundRect(f,r,r,p);p.setShader(null);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(d);p.setColor(ChatLook542.hint(owner,target)?ThemeCatalog.get(owner).accent:AppearancePalette.border(SimpleAppearance.dark(owner)));c.drawRoundRect(f,r,r,p);p.setStyle(Paint.Style.FILL);
  if(target!=null&&target.isSelected()){p.setColor(Color.WHITE);c.drawRoundRect(f.centerX()-9*d,f.top+4*d,f.centerX()+9*d,f.top+6*d,d,d,p);}if(icon==0)return;
  int save=c.save();c.translate(f.centerX()-12*d,f.centerY()-12*d);float iconScale=ButtonStudio.iconSize(owner,icon)/24f;c.translate(12*d,12*d);c.scale(iconScale,iconScale);c.translate(-12*d,-12*d);c.scale(d,d);p.setColor(active||icon==4||(target!=null&&target.isSelected())?Color.WHITE:AppearancePalette.ink(SimpleAppearance.dark(owner)));p.setStrokeWidth(1.7f);p.setStrokeCap(Paint.Cap.ROUND);p.setStrokeJoin(Paint.Join.ROUND);p.setStyle(Paint.Style.STROKE);Path q=new Path();
  switch(icon){
   case 1:q.moveTo(4,10);q.lineTo(8,10);q.lineTo(12,6);q.lineTo(12,18);q.lineTo(8,14);q.lineTo(4,14);q.close();c.drawPath(q,p);c.drawArc(10,7,20,17,-60,120,false,p);c.drawArc(9,4,24,20,-55,110,false,p);break;
   case 2:p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));p.setTextSize(12);p.setStyle(Paint.Style.FILL);c.drawText("A",4,13,p);p.setStyle(Paint.Style.STROKE);c.drawLine(13,6,21,6,p);c.drawLine(17,4,17,8,p);c.drawLine(14,8,20,13,p);c.drawLine(20,8,14,13,p);c.drawLine(5,18,19,18,p);c.drawLine(16,15,19,18,p);c.drawLine(16,21,19,18,p);break;
   case 3:c.drawRoundRect(9,3,15,14,3,3,p);c.drawArc(6,6,18,18,0,180,false,p);c.drawLine(12,18,12,21,p);c.drawLine(9,21,15,21,p);break;
   case 4:q.moveTo(4,4);q.lineTo(21,12);q.lineTo(4,20);q.lineTo(7,12);q.close();c.drawPath(q,p);c.drawLine(7,12,17,12,p);break;
   case 5:c.drawLine(5,12,19,12,p);c.drawLine(12,5,12,19,p);break;
   case 6:p.setStyle(Paint.Style.FILL);for(int y=5;y<=19;y+=7)c.drawCircle(12,y,1.5f,p);break;
   case 7:c.drawLine(5,12,19,12,p);break;
   case 8:p.setStyle(Paint.Style.FILL);c.drawRoundRect(7,7,17,17,1,1,p);break;
  }
  c.restoreToCount(save);p.setStyle(Paint.Style.FILL);
 }
 public void getOutline(Outline o){RectF f=frame();o.setRoundRect(Math.round(f.left),Math.round(f.top),Math.round(f.right),Math.round(f.bottom),circle?f.width()/2:radius);o.setAlpha(active?.25f:.12f);}
 public void setAlpha(int alpha){}public void setColorFilter(ColorFilter f){}public int getOpacity(){return PixelFormat.TRANSLUCENT;}
 static SofiaGlass linked(MainActivity a,View v,float radius,boolean selected,int icon,boolean circle){SofiaGlass d=new SofiaGlass(a,radius,selected,icon,circle);d.target=v;return d;}
 static void surface(MainActivity a,View v,float radius,boolean selected,int icon,boolean circle){v.setBackgroundTintList(null);v.setBackground(new RippleDrawable(ColorStateList.valueOf(selected?0x44ffffff:0x224a1d66),linked(a,v,radius,selected,icon,circle),null));v.setElevation(0);}
 static void action(MainActivity a,Button b,int icon){b.setText("");b.setPadding(0,0,0,0);surface(a,b,18,icon==4,icon,true);}
}
