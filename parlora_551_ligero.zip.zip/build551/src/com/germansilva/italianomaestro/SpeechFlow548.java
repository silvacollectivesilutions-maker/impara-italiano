package com.germansilva.italianomaestro;
import java.util.*;
/** Groups short sentences, keeps punctuation, and preserves an explicit slow rate. */
final class SpeechFlow548 {
 static float speed(float value){return Float.isNaN(value)||Float.isInfinite(value)?1f:Math.max(.55f,Math.min(1.25f,value));}
 static String[] chunks(String text){String clean=SpeechText.clean(text==null?"":text);if(clean.isEmpty())return new String[0];ArrayList<String> out=new ArrayList<>();String remaining=clean;while(remaining.length()>360){int cut=remaining.lastIndexOf(' ',360);if(cut<80)cut=360;if(cut<remaining.length()&&Character.isHighSurrogate(remaining.charAt(cut-1)))cut--;out.add(remaining.substring(0,cut).trim());remaining=remaining.substring(cut).trim();}if(!remaining.isEmpty())out.add(remaining);return out.toArray(new String[0]);}
}
