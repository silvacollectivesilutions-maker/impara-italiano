package com.germansilva.italianomaestro;
import android.view.*;
final class ChatCards546{
 static final int ROLE=0x7e005610;static final String[] KEYS={"","sofia546_card_it","sofia546_card_es","sofia546_card_use","sofia546_card_rule","sofia546_card_task"},NAMES={"","Italiano","Español","Cuándo y por qué","Regla clara","Tu turno"};
 static int role(View v){Object r=v.getTag(ROLE);return r instanceof Integer?(Integer)r:0;}
 static int fill(MainActivity a,View v,int fallback){int r=role(v);if(r<1||r>=KEYS.length)return fallback;int suggested=StudySurface545.color(ThemeCatalog.get(a).panel,ThemeCatalog.get(a).accent,SimpleAppearance.dark(a),r==1?2:r==2?3:4);return a.prefs.getInt(KEYS[r],suggested);}
 static int ink(MainActivity a,View v,int inherited){return role(v)==0?inherited:ColorMath542.ink(fill(a,v,0));}
 static void tag(MainActivity a,View v,int role){v.setTag(ROLE,role);v.setOnLongClickListener(x->{palette(a,role);return true;});}
 static void palette(MainActivity a,int role){View dummy=new View(a);dummy.setTag(ROLE,role);ColorPicker544.open(a,NAMES[role]+" · fondo",fill(a,dummy,ThemeCatalog.get(a).panel),"Ciao! · Hola · Tu aprendizaje",c->{a.prefs.edit().putInt(KEYS[role],c).apply();ChatLook542.refresh(a);},()->{a.prefs.edit().remove(KEYS[role]).apply();ChatLook542.refresh(a);});}
 static void open(MainActivity a){DeskUI.Page ui=new DeskUI.Page(a,"Interior de las tarjetas",false);ui.more.setVisibility(View.GONE);for(int i=1;i<KEYS.length;i++){final int role=i;ui.action(NAMES[i],()->palette(a,role),false);}ui.show();}
}
