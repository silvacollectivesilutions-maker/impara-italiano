package com.germansilva.italianomaestro;
import android.view.*;import android.widget.*;
final class NoteLook539{
 static final int COLOR=0x7e003903,MODE=0x7e003904;
 static int custom(int rgb){return (rgb>>>24)==255?rgb:0;}
 static int resolve(int value,boolean night){if(custom(value)!=0)return value;int[] dark={0xff322d20,0xff19362e,0xff1b2d42,0xff30233e},light={0xfffff3cc,0xffdef4e9,0xffe4efff,0xfff0e5ff};return (night?dark:light)[Math.max(0,Math.min(3,value))];}
 static int field(int paper){return ColorMath542.mix(paper,ColorMath542.light(paper)<.3?0xffffffff:0xff000000,.035f);}
 static void store(org.json.JSONObject note,int rgb)throws org.json.JSONException{if(custom(rgb)!=0)note.put("paper_rgb",rgb);else note.remove("paper_rgb");}
 static void apply(MainActivity a,View box,int color){box.setTag(Finish539.LOCK,true);box.setTag(COLOR,color);box.setTag(MODE,ThemeCatalog.id(a));int paper=resolve(color,SimpleAppearance.dark(a));box.setBackground(DeskUI.background(a,paper));paintPaper(a,box,paper);}
 static void paint(MainActivity a,View v,boolean night){Object color=v.getTag(COLOR);paintPaper(a,v,resolve(color instanceof Integer?(Integer)color:0,night));}
 static void paintPaper(MainActivity a,View v,int paper){if(v instanceof TextView){TextView t=(TextView)v;if(v instanceof EditText){int fill=field(paper),ink=ColorMath542.ink(fill);t.setTextColor(ink);t.setHintTextColor(ink);v.setBackgroundTintList(null);v.setBackground(DeskUI.background(a,fill));}else if(v instanceof Button){int fill=ThemeCatalog.get(a).control;t.setTextColor(ColorMath542.ink(fill));t.setTextSize(11);v.setBackground(DeskUI.background(a,fill));}else t.setTextColor(ColorMath542.ink(paper));}if(v instanceof ViewGroup){ViewGroup g=(ViewGroup)v;for(int i=0;i<g.getChildCount();i++)paintPaper(a,g.getChildAt(i),paper);}}
}
