package com.germansilva.italianomaestro;
import android.view.*;import android.graphics.*;import android.os.SystemClock;import android.animation.ValueAnimator;
/** Italian AI studio with restrained native light motes; existing avatar stays untouched. */
final class OrbBackdrop542 extends View{
 final MainActivity a;final Paint p=new Paint(3);final RectF dst=new RectF();final Rect crop=new Rect();final Matrix sphere=new Matrix();final Shader[] spheres=new Shader[6];Bitmap art;String loaded;boolean queued,attached;final Runnable tick=()->{queued=false;if(running()){invalidate();schedule();}};
 OrbBackdrop542(MainActivity a){super(a);this.a=a;setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);setClickable(false);int[] bases={0xff2eaeaa,0xffdfbf81,0xff3d7fc9,0xff79c6b8,0xff366db0,0xffc0ad86};for(int i=0;i<6;i++)spheres[i]=new RadialGradient(-.32f,-.38f,1.4f,new int[]{0xeef4ffff,bases[i],0xff071823},new float[]{0,.28f,1},Shader.TileMode.CLAMP);}
 boolean running(){return MotionMath542.run(attached,isShown()&&getWindowVisibility()==VISIBLE,hasWindowFocus(),a.prefs.getBoolean("sofia542_motion",true)&&a.prefs.getBoolean("sofia542_backdrop",true)&&ValueAnimator.areAnimatorsEnabled(),a.page==1);}
 void schedule(){if(!queued&&running()){queued=true;postDelayed(tick,a.busy?66:33);}}
 void loadArt(){String path=SceneGallery546.path(SceneGallery546.safe(a.prefs.getInt(SceneGallery546.KEY,0)));if(path.equals(loaded))return;try(java.io.InputStream in=a.getAssets().open(path)){Bitmap next=BitmapFactory.decodeStream(in);if(next!=null){art=next;loaded=path;}}catch(Exception ignored){}}
 void sync(){if(attached)loadArt();removeCallbacks(tick);queued=false;invalidate();schedule();}
 protected void onAttachedToWindow(){super.onAttachedToWindow();attached=true;sync();}
 protected void onDetachedFromWindow(){attached=false;removeCallbacks(tick);queued=false;art=null;loaded=null;super.onDetachedFromWindow();}
 protected void onWindowVisibilityChanged(int v){super.onWindowVisibilityChanged(v);if(a!=null)sync();}
 protected void onVisibilityChanged(View v,int visibility){super.onVisibilityChanged(v,visibility);if(a!=null)sync();}
 public void onWindowFocusChanged(boolean focus){super.onWindowFocusChanged(focus);if(a!=null)sync();}
 protected void onDraw(Canvas c){super.onDraw(c);c.drawColor(0xff07182b);if(!a.prefs.getBoolean("sofia542_backdrop",true))return;int power=Math.max(0,Math.min(100,a.prefs.getInt("sofia542_intensity",65)));dst.set(0,0,getWidth(),getHeight());p.setShader(null);p.setAlpha(Math.round(255*power/100f));if(art!=null){float scale=Math.max(getWidth()/(float)art.getWidth(),getHeight()/(float)art.getHeight());if(scale>0){int cw=Math.min(art.getWidth(),Math.round(getWidth()/scale)),ch=Math.min(art.getHeight(),Math.round(getHeight()/scale));int left=(art.getWidth()-cw)/2,top=(art.getHeight()-ch)/2;crop.set(left,top,left+cw,top+ch);c.drawBitmap(art,crop,dst,p);}}double seconds=a.prefs.getBoolean("sofia542_motion",true)&&ValueAnimator.areAnimatorsEnabled()?SystemClock.uptimeMillis()/1000.:0;float d=getResources().getDisplayMetrics().density;for(int i=0;i<6;i++){float x=MotionMath542.x(i,seconds)*getWidth(),y=MotionMath542.y(i,seconds)*getHeight();p.setShader(null);p.setColor(i%2==0?0xff8fdcd2:0xffd4c493);p.setAlpha(Math.round(110*power/100f));c.drawCircle(x,y,(i%2==0?1.1f:1.7f)*d,p);}p.setShader(null);p.setAlpha(255);schedule();}
}
