package com.germansilva.italianomaestro;
final class ColorMath542{
 static double channel(int c){double n=c/255.;return n<=.04045?n/12.92:Math.pow((n+.055)/1.055,2.4);}static double light(int c){return .2126*channel((c>>16)&255)+.7152*channel((c>>8)&255)+.0722*channel(c&255);}static double contrast(int a,int b){double x=light(a),y=light(b);return (Math.max(x,y)+.05)/(Math.min(x,y)+.05);}
 static int mix(int a,int b,float f){int r=Math.round(((a>>16)&255)*(1-f)+((b>>16)&255)*f),g=Math.round(((a>>8)&255)*(1-f)+((b>>8)&255)*f),bl=Math.round((a&255)*(1-f)+(b&255)*f);return 0xff000000|(r<<16)|(g<<8)|bl;}
 static final java.util.Map<Integer,int[]> CACHE=new java.util.HashMap<>();
 static synchronized int[] edges(int c){int[] result=CACHE.get(c);if(result!=null)return result;int top=mix(c,0xffffffff,.045f),bottom=mix(c,0xff000000,.04f);double white=Math.min(contrast(0xffffffff,top),contrast(0xffffffff,bottom)),black=Math.min(contrast(0xff000000,top),contrast(0xff000000,bottom));if(Math.max(white,black)<4.5){top=c;bottom=c;white=contrast(0xffffffff,c);black=contrast(0xff000000,c);}result=new int[]{top,bottom,white>=black?0xffffffff:0xff000000};if(CACHE.size()>512)CACHE.clear();CACHE.put(c,result);return result;}
 static int top(int c){return edges(c)[0];}static int bottom(int c){return edges(c)[1];}static int ink(int c){return edges(c)[2];}
 static final int[] COLORS=ColorPacks544.COLORS;
 static final String[] NAMES=ColorPacks544.NAMES;
}
