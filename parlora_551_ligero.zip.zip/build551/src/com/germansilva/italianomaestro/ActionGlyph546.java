package com.germansilva.italianomaestro;
import android.graphics.*;import android.graphics.drawable.Drawable;import android.widget.Button;
final class ActionGlyph546 extends Drawable{
 final Button b;final String name;final Paint p=new Paint(3);final Path path=new Path();final float density;
 ActionGlyph546(Button b,String name){this.b=b;this.name=name;density=b.getResources().getDisplayMetrics().density;}
 public int getIntrinsicWidth(){return Math.round(21*density);}public int getIntrinsicHeight(){return Math.round(21*density);}
 public void draw(Canvas c){c.save();c.translate(getBounds().left,getBounds().top);c.scale(getBounds().width()/24f,getBounds().height()/24f);p.setColor(b.getCurrentTextColor());p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1.7f);p.setStrokeCap(Paint.Cap.ROUND);p.setStrokeJoin(Paint.Join.ROUND);
 if(name.equals("Oír")){path.reset();path.moveTo(3,9);path.lineTo(7,9);path.lineTo(12,5);path.lineTo(12,19);path.lineTo(7,15);path.lineTo(3,15);path.close();c.drawPath(path,p);c.drawArc(10,5,22,19,-55,110,false,p);c.drawArc(12,8,18,16,-55,110,false,p);}
 else if(name.equals("Parar")){c.drawRoundRect(5,5,19,19,2,2,p);}
 else if(name.equals("Traducir")){p.setStyle(Paint.Style.FILL);p.setTypeface(Typeface.create("sans-serif-medium",Typeface.BOLD));p.setTextSize(13);c.drawText("A",2,13,p);p.setStyle(Paint.Style.STROKE);c.drawLine(13,6,21,6,p);c.drawLine(17,3,17,6,p);c.drawLine(14,9,20,15,p);c.drawLine(20,7,14,15,p);c.drawLine(3,20,19,20,p);c.drawLine(16,17,19,20,p);c.drawLine(16,23,19,20,p);}
 else if(name.equals("Explicar")){c.drawCircle(12,12,9,p);c.drawLine(12,11,12,17,p);p.setStyle(Paint.Style.FILL);c.drawCircle(12,7,1,p);}
 else if(name.equals("Columnas")){for(int i=0;i<3;i++)c.drawRoundRect(2+i*7,4,7+i*7,20,1,1,p);}
 else if(name.equals("Compartir")){c.drawLine(7,11,17,6,p);c.drawLine(7,13,17,18,p);c.drawCircle(5,12,3,p);c.drawCircle(19,5,3,p);c.drawCircle(19,19,3,p);}
 else if(name.equals("Guardar")){path.reset();path.moveTo(6,3);path.lineTo(18,3);path.lineTo(18,21);path.lineTo(12,17);path.lineTo(6,21);path.close();c.drawPath(path,p);}
 else{c.drawCircle(12,12,9,p);p.setStyle(Paint.Style.FILL);c.drawCircle(8,9,1.6f,p);c.drawCircle(14,7,1.6f,p);c.drawCircle(17,13,1.6f,p);c.drawCircle(10,16,1.6f,p);}c.restore();}
 public void setAlpha(int a){}public void setColorFilter(ColorFilter f){}public int getOpacity(){return PixelFormat.TRANSLUCENT;}
}
