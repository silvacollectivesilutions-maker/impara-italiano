from pathlib import Path
import zipfile,struct,copy,os
s=Path('build551/manifest_base.py').read_text().split('source=Path(')[0].replace('==51','==93').replace('at+16,52','at+16,94').replace("=='5.8'","=='5.50'").replace("value='5.9'","value='5.51'");ns={};exec(s,ns)

source=Path('Parlora_5_50.apk')
with zipfile.ZipFile(source) as a,source.open('rb') as raw,open('build551/unsigned-revision2.apk','wb') as dest:
 with zipfile.ZipFile(dest,'w') as z:
  for old in a.infolist():
   n=old.filename
   if n.upper()=='META-INF/MANIFEST.MF' or (n.startswith('META-INF/') and n.upper().endswith(('.RSA','.SF','.DSA','.EC'))):continue
   item=copy.copy(old);p=Path('build551/merged')/n
   asset=Path('build551/replacements')/n
   if asset.is_file():p=asset
   if n in ['AndroidManifest.xml','resources.arsc'] or p.is_file():
    data=ns['manifest'](a.read(n)) if n=='AndroidManifest.xml' else a.read(n) if n=='resources.arsc' else p.read_bytes();item.extra=b''
    if item.compress_type==0:
     base=dest.tell()+30+len(n.encode());pad=(-base-4)%4;item.extra=struct.pack('<HH',0xd935,pad)+b'\0'*pad
    z.writestr(item,data);continue
   raw.seek(old.header_offset+26);namelen,extralen=struct.unpack('<HH',raw.read(4));raw.seek(old.header_offset+30+namelen+extralen);payload=raw.read(old.compress_size);item.header_offset=dest.tell();item.flag_bits&=~8
   if item.compress_type==0:
    base=dest.tell()+30+len(n.encode())+len(item.extra)
    if base%4:pad=(-base-4)%4;item.extra+=struct.pack('<HH',0xd935,pad)+b'\0'*pad
   dest.write(item.FileHeader(False));dest.write(payload);z.filelist.append(item);z.NameToInfo[n]=item;z.start_dir=dest.tell();z._didModify=True
  item=zipfile.ZipInfo('classes45.dex');base=dest.tell()+30+len(item.filename.encode());pad=(-base-4)%4;item.extra=struct.pack('<HH',0xd935,pad)+b'\0'*pad;z.writestr(item,Path('build551/merged/classes45.dex').read_bytes())
  for asset in Path('build551/replacements/assets').rglob('*'):
   if asset.is_file() and str(asset.relative_to('build551/replacements')) not in z.NameToInfo:z.writestr(str(asset.relative_to('build551/replacements')),asset.read_bytes(),compress_type=zipfile.ZIP_DEFLATED)
 dest.flush();os.fsync(dest.fileno())
with zipfile.ZipFile('build551/unsigned-revision2.apk') as z:assert z.testzip() is None
print('PASS APK 5.50/code93 assembled with stored alignment and CRC')

import shutil
with open("build551/unsigned-revision2.apk","rb") as source,open("build551/unsigned-sequential2.apk","wb") as out:
 shutil.copyfileobj(source,out,1024*1024);out.flush();os.fsync(out.fileno())
with zipfile.ZipFile("build551/unsigned-sequential2.apk") as z:assert z.testzip() is None
