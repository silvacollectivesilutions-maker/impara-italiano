package com.germansilva.italianomaestro;
/** Plain display text; preserve paragraphs, accents, apostrophes and numbers. */
final class EasyText {
 static final String RULES=" Respeta el idioma y formato solicitados. Explica una idea por vez para un principiante, con palabras comunes y ejemplos cotidianos. En texto puedes usar **negritas** y viñetas; no uses LaTeX. Si se exige JSON respeta exactamente su estructura. Explica cualquier término técnico. Si la solicitud exige JSON, conserva exactamente ese JSON; aplica estas reglas solo a sus textos. No inventes reglas: el passato prossimo también cuenta hechos terminados de hace tiempo. ";
 static String clean(String raw){if(raw==null)return "";return raw.replace("\r\n","\n").replace("\u00a0"," ").replace("\u200b","")
 .replaceAll("(?m)^\\s*```[^\\n]*\\n?", "")
 .replaceAll("(?m)^\\s*#{1,6}\\s*", "")
 .replaceAll("(?m)^\\s*[-_=]{3,}\\s*$", "")
 .replace("\\rightarrow", " pasa a ").replace("\\to", " pasa a ")
 .replace("\\text{", "").replace("\\mathrm{", "")
 .replaceAll("[`$]", "").replaceAll("(?<=\\p{L})_(?=\\p{L})", " ")
 .replaceAll("(?m)^_+|_+$", "").replaceAll("\\n{3,}", "\n\n").trim();}
}
