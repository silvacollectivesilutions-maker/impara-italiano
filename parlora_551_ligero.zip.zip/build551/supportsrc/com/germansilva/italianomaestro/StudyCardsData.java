package com.germansilva.italianomaestro;
import org.json.*;import java.text.Normalizer;import java.util.*;
/** Structured model output or a real three-column Markdown table. Never invents missing translations. */
final class StudyCardsData{
 final String title,intro,rule,exercise;final JSONArray rows;
 StudyCardsData(String t,String i,String r,String e,JSONArray rows){title=t;intro=i;rule=r;exercise=e;this.rows=rows;}
 static String clean(String s){return s==null?"":s.replace("**","").replace("`","").trim();}
 static String norm(String s){return Normalizer.normalize(s,Normalizer.Form.NFD).replaceAll("\\p{M}","").toLowerCase(Locale.ROOT);}
 static String value(JSONObject o,String...keys){for(String key:keys){if(o.isNull(key))continue;String s=clean(o.optString(key,"").trim());if(!s.isEmpty())return s;}return "";}
 static StudyCardsData parse(String raw){if(raw==null||raw.length()>80000)return null;
  int start=raw.indexOf('{'),end=raw.lastIndexOf('}');if(start>=0&&end>start)try{JSONObject o=new JSONObject(raw.substring(start,end+1));JSONArray source=o.optJSONArray("filas");if(source==null)source=o.optJSONArray("tarjetas");if(source!=null){if(source.length()==0||source.length()>12)return null;JSONArray rows=new JSONArray();for(int i=0;i<source.length();i++){JSONObject q=source.optJSONObject(i);if(q==null)return null;String it=value(q,"it","italiano"),es=value(q,"es","espanol","español"),use=value(q,"uso","explicacion","explicación");if(it.isEmpty()||es.isEmpty()||use.isEmpty()||it.length()>800||es.length()>1200||use.length()>2000)return null;rows.put(new JSONObject().put("it",it).put("es",es).put("uso",use));}return new StudyCardsData(value(o,"titolo","titulo","título"),value(o,"spiegazione","explicacion","explicación"),value(o,"regla","regola"),value(o,"practica","práctica","esercizio"),rows);}}catch(Exception ignored){}
  return markdown(raw);
 }
 static List<String> cells(String line){String s=line.trim();if(s.startsWith("|"))s=s.substring(1);if(s.endsWith("|")&&!s.endsWith("\\|"))s=s.substring(0,s.length()-1);ArrayList<String> out=new ArrayList<>();StringBuilder v=new StringBuilder();boolean escape=false;for(char c:s.toCharArray()){if(escape){v.append(c);escape=false;}else if(c=='\\')escape=true;else if(c=='|'){out.add(clean(v.toString()));v.setLength(0);}else v.append(c);}if(escape)v.append('\\');out.add(clean(v.toString()));return out;}
 static StudyCardsData markdown(String raw){String[] lines=raw.replace("\r","").split("\n");int header=-1;for(int i=0;i<lines.length;i++){if(!lines[i].contains("|"))continue;List<String> c=cells(lines[i]);if(c.size()==3){String first=norm(c.get(0)),second=norm(c.get(1)),third=norm(c.get(2));if(first.contains("italian")&&(second.contains("espan")||second.contains("significado")||second.contains("traduc")||second.contains("spagn")||second.contains("significat")||second.contains("spanish"))&&(third.contains("uso")||third.contains("cuando")||third.contains("explica")||third.contains("regla")||third.contains("quando")||third.contains("usar")||third.contains("contesto")||third.contains("use"))){header=i;break;}}}if(header<0)return null;
  JSONArray rows=new JSONArray();StringBuilder prose=new StringBuilder();for(int i=0;i<header;i++)if(!lines[i].trim().startsWith("```"))prose.append(lines[i]).append('\n');boolean done=false;
  for(int i=header+1;i<lines.length;i++){String line=lines[i].trim();if(line.startsWith("```"))continue;if(!done&&line.contains("|")){List<String> c=cells(line);if(c.size()!=3)return null;if(c.get(0).matches("[: \\-]+")&&c.get(1).matches("[: \\-]+")&&c.get(2).matches("[: \\-]+"))continue;if(c.get(0).isEmpty()||c.get(1).isEmpty()||c.get(2).isEmpty())return null;try{rows.put(new JSONObject().put("it",c.get(0)).put("es",c.get(1)).put("uso",c.get(2)));}catch(Exception e){return null;}if(rows.length()>12)return null;}else{if(!line.isEmpty())done=true;prose.append(line).append('\n');}}
  return rows.length()==0?null:new StudyCardsData("",clean(prose.toString()),"","",rows);
 }
}
