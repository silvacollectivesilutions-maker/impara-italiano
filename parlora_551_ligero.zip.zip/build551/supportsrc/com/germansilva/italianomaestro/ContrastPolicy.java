package com.germansilva.italianomaestro;
/** Android-independent sRGB contrast and alpha composition. */
final class ContrastPolicy {
 static double channel(int n){double v=n/255.0;return v<=.04045?v/12.92:Math.pow((v+.055)/1.055,2.4);}
 static double luminance(int c){return .2126*channel(c>>16&255)+.7152*channel(c>>8&255)+.0722*channel(c&255);}
 static double ratio(int a,int b){double x=luminance(a),y=luminance(b);return (Math.max(x,y)+.05)/(Math.min(x,y)+.05);}
 static int over(int fg,int bg){double a=(fg>>>24)/255.0;int r=(int)Math.round((fg>>16&255)*a+(bg>>16&255)*(1-a)),g=(int)Math.round((fg>>8&255)*a+(bg>>8&255)*(1-a)),b=(int)Math.round((fg&255)*a+(bg&255)*(1-a));return 0xff000000|r<<16|g<<8|b;}
 static int fit(int desired,int background){int shown=over(desired,background);if(ratio(shown,background)>=4.5)return desired;return ratio(0xffffffff,background)>=ratio(0xff000000,background)?0xffffffff:0xff000000;}
 static int blend(int a,int b){return 0xff000000|(((a>>16&255)+(b>>16&255))/2)<<16|(((a>>8&255)+(b>>8&255))/2)<<8|((a&255)+(b&255))/2;}
}
