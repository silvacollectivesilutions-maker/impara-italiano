package com.germansilva.italianomaestro;
import android.view.*;import android.widget.*;import java.util.*;
public final class ModernMenus{
 static final WeakHashMap<MenuItem,MenuItem.OnMenuItemClickListener> CLICKS=new WeakHashMap<>();static final WeakHashMap<PopupMenu,PopupMenu.OnMenuItemClickListener> GENERAL=new WeakHashMap<>();
 public static MenuItem listen(MenuItem item,MenuItem.OnMenuItemClickListener listener){CLICKS.put(item,listener);return item.setOnMenuItemClickListener(listener);}
 public static void listener(PopupMenu popup,PopupMenu.OnMenuItemClickListener listener){GENERAL.put(popup,listener);popup.setOnMenuItemClickListener(listener);}
 static boolean can(PopupMenu popup,MenuItem item){return CLICKS.containsKey(item)||GENERAL.containsKey(popup);}
 static void choose(PopupMenu popup,MenuItem item){MenuItem.OnMenuItemClickListener one=CLICKS.get(item);if(one!=null)one.onMenuItemClick(item);else{PopupMenu.OnMenuItemClickListener all=GENERAL.get(popup);if(all!=null)all.onMenuItemClick(item);}}
}
