package com.germansilva.italianomaestro;
import android.content.SharedPreferences;import java.util.*;
/** Reversible, section-bound preference preview, independent from model/chat data. */
final class StylePreview{
 final SharedPreferences prefs;final Map<String,Object> before=new LinkedHashMap<>();boolean committed;
 StylePreview(SharedPreferences p,String...keys){prefs=p;Map<String,?> all=p.getAll();for(String k:keys)before.put(k,all.get(k));}
 static void put(SharedPreferences.Editor ed,String key,Object v){if(v==null)ed.remove(key);else if(v instanceof Integer)ed.putInt(key,(Integer)v);else if(v instanceof Boolean)ed.putBoolean(key,(Boolean)v);else if(v instanceof String)ed.putString(key,(String)v);}
 void commit(){committed=true;}
 void finish(){if(committed)return;SharedPreferences.Editor ed=prefs.edit();for(Map.Entry<String,Object> e:before.entrySet())put(ed,e.getKey(),e.getValue());ed.apply();}
}
