package com.germansilva.italianomaestro;
import java.util.regex.*;import java.util.*;
final class ReplyParts {
 final String italian,spanish;ReplyParts(String i,String s){italian=i;spanish=s;}
 static final Pattern LABEL=Pattern.compile("(?iu)\\b(ITALIANO|ESPAÑOL|ESPANOL|PRONUNCIACI[ÓO]N)\\s*:\\s*");
 static ReplyParts parse(String raw){return new ReplyParts(EasyText.clean(raw),"");}
 static ReplyParts oldParse(String raw){if(ProfileStore.current()!=null)return new ReplyParts(EasyText.clean(raw),"");return originalParse(raw);}
 static ReplyParts originalParse(String raw){String clean=EasyText.clean(raw).replace('\u00a0',' ').replace("\u200b","").replace("\r\n","\n").trim();Matcher m=LABEL.matcher(clean);LinkedHashSet<String> it=new LinkedHashSet<>(),es=new LinkedHashSet<>();int last=0;String label="ITALIANO";while(m.find()){append(label,clean.substring(last,m.start()),it,es);label=m.group(1).toUpperCase(Locale.ROOT);last=m.end();}append(label,clean.substring(last),it,es);return new ReplyParts(String.join("\n\n",it),String.join("\n\n",es));}
 static int score(String value,String words){Matcher m=Pattern.compile("(?iu)\\b(?:"+words+")\\b").matcher(value);int n=0;while(m.find())n++;return n;}
 static void append(String label,String chunk,Set<String> it,Set<String> es){if(label.startsWith("PRONUNCIACI"))return;for(String p:chunk.trim().split("\\n\\s*\\n")){p=p.trim();if(p.isEmpty())continue;int italian=score(p,"il|gli|della|delle|siamo|avere|essere|sono|abbiamo|prova|ora|vuoi|perché|puoi|stai|allora|buongiorno|buonasera|grazie|ciao"),spanish=score(p,"español|traducción|pronunciación|tengo|puedes|hemos|para|cómo|ejemplo|pasado|significa|quiero|necesito|gracias|hola|verbos|acciones");boolean spanishLabel=label.equals("ESPAÑOL")||label.equals("ESPANOL");if(italian>=2&&spanish==0)it.add(p);else if(spanishLabel||(spanish>=2&&italian==0))es.add(p);else it.add(p);}}
}
