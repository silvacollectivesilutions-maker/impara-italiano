package com.germansilva.italianomaestro;
import android.app.*;import android.content.*;import android.view.*;import android.widget.*;
/** Original item objects and listeners are retained; no guessed menu IDs. */
public final class ModernPopupMenu extends PopupMenu{
 final Context context;Dialog sheet;OnDismissListener dismissed;public void setOnDismissListener(OnDismissListener l){dismissed=l;super.setOnDismissListener(l);}
 public ModernPopupMenu(Context c,View a){super(c,a);context=c;}public ModernPopupMenu(Context c,View a,int g){super(c,a,g);context=c;}public ModernPopupMenu(Context c,View a,int g,int attr,int res){super(c,a,g,attr,res);context=c;}
 public void show(){Context c=context;for(int i=0;i<8&&c instanceof ContextWrapper&&!(c instanceof MainActivity);i++)c=((ContextWrapper)c).getBaseContext();if(!(c instanceof MainActivity)){super.show();return;}MainActivity a=(MainActivity)c;Menu menu=getMenu();for(int i=0;i<menu.size();i++)if(menu.getItem(i).isVisible()&&!ModernMenus.can(this,menu.getItem(i))){super.show();return;}
  LinearLayout box=DeskUI.col(a);box.setPadding(a.dp(16),a.dp(10),a.dp(16),a.dp(10));box.addView(DeskUI.text(a,"Opciones",19,true));Dialog d=new Dialog(a);sheet=d;d.requestWindowFeature(Window.FEATURE_NO_TITLE);
  for(int i=0;i<menu.size();i++){final MenuItem item=menu.getItem(i);if(!item.isVisible())continue;String label=(item.isCheckable()?(item.isChecked()?"✓  ":"◯  "):"")+item.getTitle();Button b=DeskUI.button(a,label,()->{d.dismiss();ModernMenus.choose(this,item);},item.isChecked());b.setEnabled(item.isEnabled());b.setGravity(Gravity.START|Gravity.CENTER_VERTICAL);b.setMaxLines(3);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.topMargin=a.dp(5);b.setMinHeight(a.dp(44));box.addView(b,lp);}box.addView(DeskUI.button(a,"Cerrar",()->d.dismiss(),false));ScrollView scroll=new ScrollView(a);scroll.addView(box);d.setContentView(scroll);d.setOnDismissListener(x->{if(dismissed!=null)dismissed.onDismiss(this);});d.show();ModernDialogs.sheet(a,d);SimpleAppearance.dialog(d);
 }
 public void dismiss(){if(sheet!=null)sheet.dismiss();super.dismiss();}
}
