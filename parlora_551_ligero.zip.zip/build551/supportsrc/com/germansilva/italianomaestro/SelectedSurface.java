package com.germansilva.italianomaestro;
import android.graphics.*;import android.graphics.drawable.Drawable;
/** Visible selection marker in addition to color; keeps the label intact. */
final class SelectedSurface extends Drawable{final MainActivity a;final int color;final Paint p=new Paint(3);SelectedSurface(MainActivity a,int c){this.a=a;color=c;}public void draw(Canvas c){RectF r=new RectF(getBounds());r.inset(a.dp(1),a.dp(1));p.setColor(color);p.setStyle(Paint.Style.FILL);c.drawRoundRect(r,a.dp(12),a.dp(12),p);p.setColor(Color.WHITE);c.drawRoundRect(r.centerX()-a.dp(9),r.top+a.dp(4),r.centerX()+a.dp(9),r.top+a.dp(6),a.dp(1),a.dp(1),p);}public void setAlpha(int n){}public void setColorFilter(ColorFilter f){}public int getOpacity(){return PixelFormat.OPAQUE;}}
