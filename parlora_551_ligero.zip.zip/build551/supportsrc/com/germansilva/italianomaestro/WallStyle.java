package com.germansilva.italianomaestro;
import android.content.*;import android.graphics.*;import android.graphics.drawable.*;import android.view.*;import android.widget.*;import org.json.*;import java.util.*;
final class WallStyle{
 static String key(int page,String name){return page==1?name:"wall_page_"+page+"_"+name;}
 static String key(MainActivity a,String name){return key(a.page,name);}
 static int integer(MainActivity a,String name,int def){return a.prefs.getInt(key(a,name),def);}
 static boolean bool(MainActivity a,String name,boolean def){return a.prefs.getBoolean(key(a,name),def);}
 static String string(MainActivity a,String name,String def){return a.prefs.getString(key(a,name),def);}
 static final String[] KEYS={"custom_bg_file","custom_bg_builtin","custom_bg_video","custom_bg_motion","custom_bg_opacity","custom_bg_dark","custom_bg_zoom","custom_bg_x","custom_bg_y","custom_bg_blur","custom_panel_transparency","chat_text_color","chat_text_size","chat_user_color","chat_sofia_color","custom_trim_start","custom_trim_end","chat_controls_color","chat_audio_color","chat_translate_color","chat_mic_color","chat_send_color","chat_border_color","chat_gloss"};
 static JSONArray styles(MainActivity a){try{return new JSONArray(a.prefs.getString("wall_styles_v1","[]"));}catch(Exception e){return new JSONArray();}}
 static boolean used(MainActivity a,String file){if(WallpaperGallery.contains(a,file))return true;for(Object value:a.prefs.getAll().values())if(file.equals(value))return true;return a.prefs.getString("wall_styles_v1","[]").contains(file);}
 static void save(MainActivity a){EditText name=new EditText(a);name.setSingleLine(true);name.setHint("Ej. Noche azul");new android.app.AlertDialog.Builder(a).setTitle("Guardar estilo de esta sección").setView(name).setNegativeButton("Cancelar",null).setPositiveButton("Guardar",(d,w)->{try{JSONArray list=styles(a);if(list.length()>=8){a.toast("Máximo 8 estilos. Borra uno antes.");return;}JSONObject style=new JSONObject(),values=new JSONObject();String label=name.getText().toString().trim();style.put("name",label.isEmpty()?"Estilo "+(list.length()+1):label.substring(0,Math.min(40,label.length())));Map<String,?> all=a.prefs.getAll();for(String k:KEYS)if(all.containsKey(key(a,k)))values.put(k,all.get(key(a,k)));style.put("values",values);list.put(style);a.prefs.edit().putString("wall_styles_v1",list.toString()).apply();a.toast("Estilo guardado");}catch(Exception e){a.toast("No se pudo guardar el estilo");}}).show();}
 static void choose(MainActivity a){JSONArray list=styles(a);if(list.length()==0){a.toast("Guarda primero un estilo");return;}String[] names=new String[list.length()];for(int i=0;i<names.length;i++)names[i]=list.optJSONObject(i).optString("name","Estilo");new android.app.AlertDialog.Builder(a).setTitle("Mis estilos · aplicar a esta sección").setItems(names,(d,index)->{new android.app.AlertDialog.Builder(a).setTitle(names[index]).setItems(new String[]{"Aplicar","Eliminar estilo"},(d2,action)->{try{if(action==1){JSONArray next=new JSONArray();for(int j=0;j<list.length();j++)if(j!=index)next.put(list.get(j));a.prefs.edit().putString("wall_styles_v1",next.toString()).apply();a.toast("Estilo eliminado");return;}JSONObject values=list.getJSONObject(index).getJSONObject("values");String file=values.optString("custom_bg_file","");if(!file.isEmpty()&&!new java.io.File(a.getFilesDir(),file).isFile()){a.toast("La foto de este estilo ya no está disponible");return;}SharedPreferences.Editor ed=a.prefs.edit();for(String k:KEYS){ed.remove(key(a,k));if(!values.has(k))continue;Object v=values.get(k);if(v instanceof Boolean)ed.putBoolean(key(a,k),(Boolean)v);else if(v instanceof Number)ed.putInt(key(a,k),((Number)v).intValue());else if(v instanceof String)ed.putString(key(a,k),(String)v);}ed.apply();AcademiaBackdrop.refresh(a,true);a.toast("Estilo aplicado");}catch(Exception e){a.toast("No se pudo aplicar el estilo");}}).show();}).show();}
 static void colors(MainActivity a){ColorStudio.open(a);}
 static void palette(MainActivity a,String title,String key){String[] labels={"Blanco cálido","Azul noche","Turquesa oscuro","Azul intenso","Violeta","Coral oscuro","Dorado oscuro","Verde bosque","Negro","Personalizado · #RRGGBB"};int[] colors={0xfff3f1e8,0xff17283d,0xff075a60,0xff164ea0,0xff6339a5,0xff9b294e,0xff6c4e16,0xff185c42,0xff090e15};new android.app.AlertDialog.Builder(a).setTitle(title).setItems(labels,(d,i)->{if(i==9){EditText input=new EditText(a);input.setSingleLine(true);input.setHint("#2455A0");new android.app.AlertDialog.Builder(a).setTitle("Color hexadecimal").setView(input).setNegativeButton("Cancelar",null).setPositiveButton("Aplicar",(x,w)->{try{String s=input.getText().toString().trim();if(!s.matches("#[0-9a-fA-F]{6}"))throw new Exception();a.prefs.edit().putInt(key(1,key),Color.parseColor(s)).apply();AcademiaBackdrop.refresh(a,false);}catch(Exception e){a.toast("Escribe 6 dígitos, por ejemplo #2455A0");}}).show();}else{a.prefs.edit().putInt(key(1,key),colors[i]).apply();AcademiaBackdrop.refresh(a,false);}}).show();}
 static void applyChat(MainActivity a){if(a.page!=1||a.chat==null)return;applyText(a,a.chat);ReadingStyle.recolor(a,a.chat);ColorStudio.buttons(a.root);}
 static void applyText(MainActivity a,View v){if(Boolean.TRUE.equals(v.getTag(0x7e002601))&&v instanceof TextView){TextView t=(TextView)v;t.setTextColor(a.prefs.getInt("chat_text_color",0xfff3f1e8));t.setTextSize(a.prefs.getInt("chat_text_size",16));}if(v instanceof ViewGroup)for(int i=0;i<((ViewGroup)v).getChildCount();i++)applyText(a,((ViewGroup)v).getChildAt(i));}
 static final class Bubble extends Drawable{
  final MainActivity a;final boolean user;final Paint p=new Paint(3);
  Bubble(MainActivity a,boolean user){this.a=a;this.user=user;}
  public void draw(Canvas c){
   int base=a.prefs.getInt(user?"chat_user_color":"chat_sofia_color",user?0xff007d70:0xff1258a7);
   // Migrate only the former stock colors; preserve intentional custom palettes.
   
   int tr=Math.max(0,Math.min(100,a.prefs.getInt("custom_panel_transparency",28)));
   int alpha=Math.round(255*(100-tr)/100f);
   RectF r=new RectF(getBounds());float d=a.getResources().getDisplayMetrics().density;r.inset(d,d);
   int light=Color.rgb(Math.min(255,Color.red(base)+24),Math.min(255,Color.green(base)+35),Math.min(255,Color.blue(base)+30));
   int dark=Color.rgb(Color.red(base)*55/100,Color.green(base)*55/100,Color.blue(base)*65/100);
   p.setStyle(Paint.Style.FILL);boolean gloss=a.prefs.getBoolean("chat_gloss",true);p.setShader(gloss?new LinearGradient(r.left,r.top,r.left,r.bottom,new int[]{(alpha<<24)|(light&0xffffff),(alpha<<24)|(base&0xffffff),(alpha<<24)|(dark&0xffffff)},new float[]{0,.22f,1},Shader.TileMode.CLAMP):null);p.setColor(gloss?Color.WHITE:((alpha<<24)|(base&0xffffff)));
   c.drawRoundRect(r,16*d,16*d,p);p.setShader(null);
   p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1.2f*d);p.setColor((a.prefs.getInt("chat_border_color",user?0xff66f8dc:0xff78d9ff)&0xffffff)|0xcc000000);c.drawRoundRect(r,16*d,16*d,p);
   if(gloss){r.inset(1.5f*d,1.5f*d);p.setStrokeWidth(d);p.setShader(new LinearGradient(0,r.top,0,r.bottom,0x77ffffff,0x00ffffff,Shader.TileMode.CLAMP));c.drawRoundRect(r,14*d,14*d,p);p.setShader(null);}p.setStyle(Paint.Style.FILL);
  }
  public void setAlpha(int n){}public void setColorFilter(ColorFilter f){}public int getOpacity(){return PixelFormat.TRANSLUCENT;}
 }
}
