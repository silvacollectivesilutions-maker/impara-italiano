package com.germansilva.italianomaestro;
import java.text.Normalizer;import java.util.Locale;
/** Recognizes only the existing More/IA labels; never guesses navigation destinations. */
final class MorePlan{
 static String normal(String s){return Normalizer.normalize(s==null?"":s,Normalizer.Form.NFD).replaceAll("\\p{M}","").toLowerCase(Locale.ROOT).replaceAll("\\s+"," ").trim();}
 static int action(String label){String t=normal(label);if(t.contains("sofia")&&(t.contains("conversar")||t.startsWith("abrir")))return 0;if(t.contains("motor")&&t.contains("memoria"))return 1;if(t.contains("centro ia"))return 2;return -1;}
 static boolean legacyTitle(String s){String t=normal(s);return t.startsWith("sofia")&&t.contains("imagenes")&&t.contains("audio");}
 static final String[] SHORT={"Sofía","Motor y memoria","Centro IA"};
}
