package com.germansilva.italianomaestro;
import org.json.*;
/** Local gallery index. The original phone media is never deleted. */
final class GalleryData{
 static boolean safe(String name){return name!=null&&name.matches("wallpaper-[a-z0-9-]+\\.media");}
 static JSONArray read(String raw){JSONArray out=new JSONArray();try{JSONArray items=new JSONArray(raw);java.util.Set<String> seen=new java.util.HashSet<>();for(int i=0;i<items.length();i++){JSONObject x=items.optJSONObject(i);if(x!=null&&safe(x.optString("file"))&&seen.add(x.optString("file")))out.put(x);}}catch(Exception ignored){}return out;}
 static JSONObject add(JSONArray list,String file,boolean video,String mime)throws Exception{if(!safe(file))throw new Exception("Archivo no válido");for(int i=0;i<list.length();i++)if(file.equals(list.getJSONObject(i).optString("file")))return list.getJSONObject(i);if(list.length()>=30)throw new Exception("Tu galería admite 30 fondos. Elimina uno antes de importar otro.");JSONObject item=new JSONObject().put("file",file).put("video",video).put("mime",mime==null?"":mime).put("name",(video?"Video ":"Imagen ")+(list.length()+1));list.put(item);return item;}
 static JSONArray remove(JSONArray list,String file){JSONArray result=new JSONArray();for(int i=0;i<list.length();i++)if(!file.equals(list.optJSONObject(i).optString("file")))result.put(list.optJSONObject(i));return result;}
}
