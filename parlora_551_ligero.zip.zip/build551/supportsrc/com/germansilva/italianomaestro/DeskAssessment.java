package com.germansilva.italianomaestro;
import org.json.*;
final class DeskAssessment{
 static final String VERSION="fundamentos-1";
 static final String[] QUESTIONS={"¿Qué significa buongiorno?","Completa: Io ___ italiano.","Elige el artículo de acqua.","¿Cómo dices por favor?","¿Cómo dices Tengo una pregunta?","Plural de il bicchiere:","Completa: Noi ___ studenti.","¿Cómo dices Ayer trabajé?","¿Cómo preguntas Dónde está la estación?","¿Cómo pides amablemente un café?"};
 static final String[][] OPTIONS={{"Buenos días","Hasta mañana","Buenas noches"},{"parli","parlo","parlano"},{"il acqua","lo acqua","l’acqua"},{"Per favore","Perché","Prego, domani"},{"Sono una domanda","Ho una domanda","Faccio una domani"},{"i bicchiere","le bicchieri","i bicchieri"},{"siamo","siete","sono"},{"Domani lavorerò","Ieri ho lavorato","Adesso lavoro"},{"Come si chiama?","Quanto costa?","Dov’è la stazione?"},{"Vorrei un caffè, per favore.","Ieri ho bevuto un caffè.","Non bevo caffè."}};
 static final int[] CORRECT={0,1,2,0,1,2,0,1,2,0};
 static int result(JSONObject attempt)throws Exception{if(!VERSION.equals(attempt.getString("exam")))throw new Exception("Evaluación no reconocida");return DeskData.score(attempt.getJSONArray("responses"),CORRECT);}
 static boolean passed(JSONObject attempt)throws Exception{return result(attempt)>=8;}
}
