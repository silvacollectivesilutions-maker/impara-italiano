package com.germansilva.italianomaestro;
import android.graphics.*;import android.graphics.drawable.*;import android.view.*;import android.widget.*;
/** Runs after layout/theme painters. Uses actual native ancestor surfaces, not page names. */
final class ContrastGuard {
 static final int TAG=0x7e003201;
 static void bind(MainActivity a,View surface){if(surface==null||surface.getTag(TAG)!=null)return;surface.setTag(TAG,true);View owner=a.root;surface.getViewTreeObserver().addOnPreDrawListener(()->{if(a.root==owner&&surface.isAttachedToWindow())scan(a,surface,0xfff8f5ed);return true;});surface.post(()->{if(a.root==owner)scan(a,surface,0xfff8f5ed);});}
 static int sample(MainActivity a,Drawable d,int parent){if(d==null)return parent;
  if(d instanceof RippleDrawable){RippleDrawable r=(RippleDrawable)d;return r.getNumberOfLayers()>0?sample(a,r.getDrawable(0),parent):parent;}
  if(d instanceof ReadingStyle.Surface){ReadingStyle.Surface s=(ReadingStyle.Surface)d;return ReadingStyle.fill(a,s.base);}
  if(d instanceof WallStyle.Bubble){WallStyle.Bubble b=(WallStyle.Bubble)d;int base=a.prefs.getInt(b.user?"chat_user_color":"chat_sofia_color",b.user?0xff007d70:0xff1258a7);int alpha=Math.round(255*(100-Math.max(0,Math.min(100,a.prefs.getInt("custom_panel_transparency",28))))/100f);return ContrastPolicy.over((alpha<<24)|(base&0xffffff),parent);}
  if(d instanceof SofiaGlass){SofiaGlass s=(SofiaGlass)d;int alpha=Math.max(210,Math.round(255*(100-a.prefs.getInt("custom_panel_transparency",72))/100f));return ContrastPolicy.over((Math.min(255,alpha)<<24)|(s.base()&0xffffff),parent);}
  if(d instanceof ColorDrawable)return ContrastPolicy.over(((ColorDrawable)d).getColor(),parent);
  if(d instanceof GradientDrawable){GradientDrawable g=(GradientDrawable)d;int[] colors=g.getColors();if(colors!=null&&colors.length>0){int c=colors[0];for(int i=1;i<colors.length;i++)c=ContrastPolicy.blend(c,colors[i]);return ContrastPolicy.over(c,parent);}if(g.getColor()!=null)return ContrastPolicy.over(g.getColor().getColorForState(d.getState(),g.getColor().getDefaultColor()),parent);}
  if(d instanceof HomeDashboard.Scene){HomeDashboard.Scene s=(HomeDashboard.Scene)d;return ContrastPolicy.over(s.color,parent);}
  if(d instanceof StudyReply.Panel)return ((StudyReply.Panel)d).fill;
  return parent;
 }
 static boolean picture(MainActivity a){String file=WallStyle.string(a,"custom_bg_file","");String built=WallStyle.string(a,"custom_bg_builtin",a.page==0?"rome":"navy");return !file.isEmpty()||!built.equals("navy");}
 static boolean uncertain(Drawable d,boolean inherited){if(d==null)return inherited;if(d instanceof RippleDrawable){RippleDrawable r=(RippleDrawable)d;return r.getNumberOfLayers()==0?inherited:uncertain(r.getDrawable(0),inherited);}if(d instanceof ReadingStyle.Surface||d instanceof StudyReply.Panel)return false;if(d instanceof ColorDrawable)return (((ColorDrawable)d).getColor()>>>24)<255&&inherited;if(d instanceof GradientDrawable){GradientDrawable g=(GradientDrawable)d;int[] cs=g.getColors();if(cs!=null){for(int c:cs)if((c>>>24)<255)return inherited;return false;}return g.getColor()==null?inherited:(g.getColor().getDefaultColor()>>>24)<255&&inherited;}if(d instanceof HomeDashboard.Scene)return ((HomeDashboard.Scene)d).hero||inherited;return inherited;}
 static void scan(MainActivity a,View v,int inherited){scan(a,v,inherited,false);}
 static void scan(MainActivity a,View v,int inherited,boolean inheritedUnknown){if(true)return;if(v.getVisibility()!=View.VISIBLE||v instanceof android.webkit.WebView||v instanceof ImageView||v instanceof TextureView||v instanceof android.view.SurfaceView)return;
  if(v==a.root&&AcademiaBackdrop.current(a)!=null){inherited=0xff101925;inheritedUnknown=picture(a);}int background=sample(a,v.getBackground(),inherited);boolean unknown=uncertain(v.getBackground(),inheritedUnknown);if(v.getBackgroundTintList()!=null){int tint=v.getBackgroundTintList().getColorForState(v.getDrawableState(),v.getBackgroundTintList().getDefaultColor());background=ContrastPolicy.over(tint,background);if((tint>>>24)==255)unknown=false;}if(v instanceof TextView){TextView t=(TextView)v;if(unknown&&t.getText().length()>0&&!(t instanceof Button)){t.setBackground(ReadingStyle.panel(a,0xff20384f));background=ReadingStyle.fill(a,0xff20384f);unknown=false;}if(t.getText().length()>0){int desired=t.getCurrentTextColor(),safe=ContrastPolicy.fit(desired,background);if(safe!=desired)t.setTextColor(safe);}if(t instanceof EditText){int old=t.getCurrentHintTextColor(),safe=ContrastPolicy.fit(old,background);if(old!=safe)t.setHintTextColor(safe);}}
  if(v instanceof CompoundButton){CompoundButton c=(CompoundButton)v;android.content.res.ColorStateList tint=c.getButtonTintList();int old=tint==null?c.getCurrentTextColor():tint.getColorForState(c.getDrawableState(),tint.getDefaultColor());int safe=ContrastPolicy.fit(old,background);if(tint==null||safe!=old)c.setButtonTintList(android.content.res.ColorStateList.valueOf(safe));}
  if(v instanceof ViewGroup){ViewGroup g=(ViewGroup)v;for(int i=0;i<g.getChildCount();i++)scan(a,g.getChildAt(i),background,unknown);}
 }
}
