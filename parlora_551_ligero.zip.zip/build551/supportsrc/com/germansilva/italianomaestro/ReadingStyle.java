package com.germansilva.italianomaestro;
import android.graphics.*;import android.graphics.drawable.*;import android.content.res.ColorStateList;import android.view.*;import android.widget.*;
final class ReadingStyle {
 static final int MARK=0x7e003101;
 static int mix(int a,int b,float t){return Color.rgb(Math.round(Color.red(a)*(1-t)+Color.red(b)*t),Math.round(Color.green(a)*(1-t)+Color.green(b)*t),Math.round(Color.blue(a)*(1-t)+Color.blue(b)*t));}
 static int ink(MainActivity a){return SimpleAppearance.ink(a);}
 static int fill(MainActivity a,int base){return AppearancePalette.panel(SimpleAppearance.dark(a));}
 static int accent(MainActivity a){return mix(a.prefs.getInt("chat_controls_color",0xff185d80),ink(a),.65f);}
 static final class Surface extends Drawable{final MainActivity a;final int base;final Paint p=new Paint(3);Surface(MainActivity a,int base){this.a=a;this.base=base;}public void draw(Canvas c){RectF r=new RectF(getBounds());r.inset(a.dp(1),a.dp(1));p.setStyle(Paint.Style.FILL);p.setColor(fill(a,base));c.drawRoundRect(r,a.dp(15),a.dp(15),p);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(a.dp(1));p.setColor(mix(fill(a,base),ink(a),.18f));c.drawRoundRect(r,a.dp(15),a.dp(15),p);}public void setAlpha(int n){}public void setColorFilter(ColorFilter f){}public int getOpacity(){return PixelFormat.TRANSLUCENT;}}
 static Drawable panel(MainActivity a,int base){return new Surface(a,base);}
 static void recolor(MainActivity a,View v){if(v instanceof TextView&&Boolean.TRUE.equals(v.getTag(MARK)))((TextView)v).setTextColor(ink(a));if(v instanceof ViewGroup)for(int i=0;i<((ViewGroup)v).getChildCount();i++)recolor(a,((ViewGroup)v).getChildAt(i));}
 static TextView text(MainActivity a,String s,int size){TextView t=new TextView(a);t.setText(s);t.setTag(MARK,true);t.setTextSize(size);t.setTextColor(ContrastPolicy.fit(ink(a),fill(a,0xff20384f)));t.setIncludeFontPadding(false);t.setLineSpacing(a.dp(3),1);t.setTextIsSelectable(true);t.setBreakStrategy(0);t.setHyphenationFrequency(0);return t;}
 static LinearLayout card(MainActivity a,int color){LinearLayout c=new LinearLayout(a);c.setOrientation(1);c.setPadding(a.dp(14),a.dp(13),a.dp(14),a.dp(13));c.setBackground(panel(a,color));c.setTag(MARK,true);return c;}
 static LinearLayout.LayoutParams lp(MainActivity a,int top){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=a.dp(top);return p;}
 static void button(MainActivity a,Button b){b.setAllCaps(false);b.setTextSize(12);b.setTextColor(ink(a));b.setMinWidth(0);b.setMinimumWidth(0);b.setMinHeight(a.dp(40));b.setMinimumHeight(a.dp(40));b.setPadding(a.dp(9),a.dp(3),a.dp(9),a.dp(3));b.setSingleLine(false);b.setMaxLines(3);b.setBackgroundTintList(null);b.setBackground(new RippleDrawable(ColorStateList.valueOf(0x337fa9c5),panel(a,b.isSelected()?a.prefs.getInt("chat_send_color",0xff128675):a.prefs.getInt("chat_controls_color",0xff254769)),null));}
 static Button action(MainActivity a,String title,Runnable run){Button b=new Button(a);b.setText(title);button(a,b);b.setOnClickListener(v->run.run());return b;}
}
