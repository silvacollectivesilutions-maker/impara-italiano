package com.germansilva.italianomaestro;
final class ReadingPolicy {
 static boolean paired(int widthDp,float fontScale,int leftLength,int rightLength){return widthDp>=360&&fontScale<=1.2f&&leftLength<=65&&rightLength<=65;}
 static String[] forms(String[] verb,int tense){if(verb==null||verb.length<8||tense<0||tense>2)return new String[0];String[] f=verb[tense==0?2:tense==1?3:4].split(",");return f.length==6?f:new String[0];}
 static String gender(String verb,int tense,int person,String form){if(tense!=1)return form;String male=verb.equals("essere")?"stato":verb.equals("andare")?"andato":"";if(male.isEmpty())return form;String plural=male.substring(0,male.length()-1)+"i",female=male.substring(0,male.length()-1)+(person<3?"a":"e");String expected=person<3?male:plural;String condensed=expected+(person<3?"/a":"/e");String clean=form.endsWith(condensed)?form.substring(0,form.length()-condensed.length())+expected:form;return clean.endsWith(expected)?clean+" / "+female:form;}
 static String spokenForm(String form){return form.replaceAll("(?<=\\p{L})/[ae](?=\\s|$)","");}
 static String[] example(String[] verb,int tense){if(verb==null||verb.length<8||tense<0||tense>2)return new String[]{"",""};String[] bits=verb[tense+5].split("\\|",-1);return new String[]{bits.length>0?bits[0]:"",bits.length>1?bits[1]:""};}
 static int outputBudget(int requested){return Math.max(32,Math.min(768,requested));}
 static boolean prepareMedia(boolean attached,boolean shown,boolean windowVisible){return attached&&shown&&windowVisible;}
}
