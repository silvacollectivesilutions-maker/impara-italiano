package com.germansilva.italianomaestro;
/** Pure sizing policy shared by editor and renderer. Zero means original. */
final class ButtonSizing {
 static int compactSaved(String key,int n){int cap=key.endsWith("_height")?40:key.endsWith("_width")?100:key.endsWith("_text")?12:key.endsWith("_padding")?6:key.endsWith("_icon")?22:Integer.MAX_VALUE;return Math.min(n,cap);}
 static int clamp(int value,int lo,int hi){return Math.max(lo,Math.min(hi,value));}
 static int width(int value){return value==0?0:clamp(value,36,180);}
 static int height(int value){return value==0?0:clamp(value,36,88);}
 static int text(int value){return value==0?0:clamp(value,10,24);}
 static int icon(int value){return value==0?24:clamp(value,14,32);}
 static int padding(int value){return value<0?-1:clamp(value,0,20);}
 static int[] fit(int[] desired,int available){int total=0;for(int n:desired)total+=Math.max(0,n);int[] result=desired.clone();if(total<=available||total==0)return result;int used=0;for(int i=0;i<result.length;i++){result[i]=(int)((long)Math.max(0,desired[i])*Math.max(0,available)/total);used+=result[i];}for(int i=0;used<Math.max(0,available)&&i<result.length;i++,used++)result[i]++;return result;}
}
