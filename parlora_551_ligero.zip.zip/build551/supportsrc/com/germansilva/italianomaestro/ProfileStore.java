package com.germansilva.italianomaestro;
/** Only the single new preferences key below is mutated. Invalid documents are not overwritten. */
final class ProfileStore {
 static final String KEY="sofia_instruction_profiles_v1";
 static ProfileData load(MainActivity a)throws org.json.JSONException{return ProfileData.decode(a.prefs.getString(KEY,""));}
 static void write(MainActivity a,ProfileData d)throws Exception{if(!a.prefs.edit().putString(KEY,d.encode()).commit())throw new java.io.IOException("No se pudieron guardar los perfiles");}
 static void initialize(MainActivity a)throws Exception{if(!a.prefs.contains(KEY))write(a,ProfileData.starters());}
 static ProfileData.Profile current(){MainActivity a=SofiaHub.owner;return current(a);}
 static ProfileData.Profile current(MainActivity a){if(a==null||a.prefs==null)return null;try{return load(a).selected();}catch(Exception e){return null;}}
 static boolean freeText(){ProfileData.Profile p=current();return p!=null&&!p.language.equals("it");}
 static String caption(MainActivity a){ProfileData.Profile p=current(a);return p==null?"CONVERSACIÓN · ITALIANO":"PERFIL · "+p.name;}
}
